package org.springblade.test;

/**
 * Blade单元测试
 *
 * @author Chill
 */
//@RunWith(BladeSpringRunner.class)
//@BladeBootTest(appName = "blade-runner", profile = "test")
public class BladeTest {

	//@Test
	public void contextLoads() {
		System.out.println("测试～～～～～～");
	}

}
